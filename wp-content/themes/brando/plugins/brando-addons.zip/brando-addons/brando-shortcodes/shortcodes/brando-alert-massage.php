<?php
/**
 * Shortcode For Alert Message
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Alert Message */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'brando_alert_massage_shortcode' ) ) {
	function brando_alert_massage_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
	        	'id' => '',
	        	'class' => '',
	        	'brando_alert_massage_premade_style' => '',
	        	'brando_alert_massage_type' => '',
	        	'brando_message_icon' => '',
	        	'brando_highlight_title' => '',
	        	'brando_subtitle' => '',
	        	'show_close_button' => '',
	        	'custom_icon' => '',
                'custom_icon_image' => '',
	        ), $atts ) );
		$output = '';

		$id = ($id) ? ' id="'.$id.'"' : '';
		$class = ( $class ) ? ' '.$class : '';
		$brando_alert_massage_premade_style = ( $brando_alert_massage_premade_style ) ? $brando_alert_massage_premade_style : '';
		$brando_alert_massage_type = ( $brando_alert_massage_type ) ? ' alert-'.$brando_alert_massage_type : '';
		$brando_message_icon = ( $brando_message_icon ) ? $brando_message_icon : '';
		$brando_highlight_title = ( $brando_highlight_title ) ? $brando_highlight_title : '';
		$brando_subtitle = ( $brando_subtitle ) ? $brando_subtitle : '';
		$show_close_button = ( $show_close_button ) ? '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' : '';

		/* Image Alt, Title, Caption */
	    $img_alt = brando_option_image_alt($custom_icon_image);
	    $img_title = brando_option_image_title($custom_icon_image);
	    $image_alt = ( isset($img_alt['alt']) && !empty($img_alt['alt']) ) ? ' alt="'.$img_alt['alt'].'"' : ' alt=""' ; 
	    $image_title = ( isset($img_title['title']) && !empty($img_title['title']) ) ? ' title="'.$img_title['title'].'"' : '';

		switch ($brando_alert_massage_premade_style) 
		{
			case 'alert-massage-style-1':

			   $output .= ' <div class="alert-style1">';
	                $output .= '<div'.$id.' class="alert'.$brando_alert_massage_type.$class.'" role="alert">';
	                	if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
		                    $output .= '<img src="'.wp_get_attachment_url( $custom_icon_image ).'"'.$image_alt.$image_title.' class="icon-image" />';
		                }elseif($brando_message_icon){
                           $output .= '<i class="'.$brando_message_icon.'"></i>';
                        }
                        if($brando_highlight_title || $brando_subtitle){
                 	        $output .= '<span>';
	                 	       	if($brando_highlight_title){
	                           		$output .= '<strong>'.$brando_highlight_title.'</strong> ';
	                       		}
	                           $output .= $brando_subtitle;
                            $output .= '</span>';
                        }        
                    $output .= '</div>';
                $output .= '</div>';
                
            break;

            case 'alert-massage-style-2':

		        $output .= '<div'.$id.' role="alert" class="alert'.$brando_alert_massage_type.$class.' fade in">';
		        	if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
		                    $output .= '<img src="'.wp_get_attachment_url( $custom_icon_image ).'"'.$image_alt.$image_title.' class="icon-image'.$brando_alert_massage_type.'" />';
		            }elseif($brando_message_icon){
						$output .= '<i class="'.$brando_message_icon.$brando_alert_massage_type.'"></i>';
					}
					if($brando_highlight_title || $brando_subtitle){
		                $output .= ' <span>';
			                $output .= '<strong>'.$brando_highlight_title.'</strong> ';
			                $output .= $brando_subtitle;
		                $output .= '</span>';
	                }
	                $output .= $show_close_button;
	            $output .= '</div>';

            break;

			case 'alert-massage-style-3':

			   $output .= '<div'.$id.' role="alert" class="alert'.$brando_alert_massage_type.$class.' fade in">';
					if($brando_highlight_title || $brando_subtitle){
						$output .= '<span>';
							if($brando_highlight_title){
								$output .= '<strong>'.$brando_highlight_title.'</strong> ';
							}
							$output .= $brando_subtitle;
						$output .= '</span>';
					}
					$output .= $show_close_button;
	            $output .= '</div>';

			break;

            case 'alert-massage-style-4':

				$output .= '<div class="alert-style2">';
					$output .= '<div'.$id.' role="alert" class="alert'.$brando_alert_massage_type.$class.'">';
						if($brando_highlight_title || $brando_subtitle){
							$output .= '<span>';
								if($brando_highlight_title){
									$output .= '<strong>'.$brando_highlight_title.'</strong> ';
								}
								$output .= $brando_subtitle;
							$output .= '</span>';
						}
						$output .= $show_close_button;
		            $output .= '</div>';
		        $output .= '</div>';

		    break;

			case 'alert-massage-style-5':

				$output .= '<div'.$id.' role="alert" class="alert alert-block fade in'.$brando_alert_massage_type.$class.'">';
					$output .= $show_close_button;
					if($brando_highlight_title){
						$output .= '<span class="margin-two no-margin-top no-margin-lr alt-font font-weight-700 text-medum text-uppercase'.$brando_alert_massage_type.'">'.$brando_highlight_title.'</span>';
					}
					if($brando_subtitle){
						$output .= '<p>'.$brando_subtitle.'</p>';
					}
		        $output .= '</div>';

			break;
		}
	    return $output;
	}
}
add_shortcode('brando_alert_massage','brando_alert_massage_shortcode');
?>
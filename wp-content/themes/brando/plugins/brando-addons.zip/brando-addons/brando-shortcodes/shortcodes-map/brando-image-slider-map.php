<?php
/**
 * Map For Slider
 *
 * @package Brando
 */
?>
<?php 
/*-----------------------------------------------------------------------------------*/
/* Slider */
/*-----------------------------------------------------------------------------------*/

vc_map( 
  array(
      'name' => __( 'Image Slider' , 'brando-addons' ), //Name of your shortcode for human reading inside element list
      'base' => 'brando_slider', //Shortcode tag. For [my_shortcode] shortcode base is my_shortcode
      'description' => __( 'Place an image slider', 'brando-addons' ), //Short description of your element, it will be visible in 'Add element' window
      'class' => '', //CSS class which will be added to the shortcode's content element in the page edit screen in Visual Composer backend edit mode
      'as_parent' => array('only' => 'brando_slide_content'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
      'icon' => 'fa fa-picture-o brando-shortcode-icon', //URL or CSS class with icon image.
      'js_view' => 'VcColumnView',
      'category' => 'Brando',
      'params' => array( //List of shortcode attributes. Array which holds your shortcode params, these params will be editable in shortcode settings page
          array(
              'type' => 'dropdown',
              'heading' => __('Image Slider Style', 'brando-addons'),
              'param_name' => 'slider_premade_style',
              'admin_label' => true,
              'value' => array(__('Select a Slider Style', 'brando-addons') => '',
                               __('Slider Style 1', 'brando-addons') => 'brando-owl-slider1',
                               __('Slider Style 2', 'brando-addons') => 'brando-owl-slider2', 
                               __('Slider Style 3', 'brando-addons') => 'brando-owl-slider3',
                               __('Slider Style 4', 'brando-addons') => 'brando-owl-slider4',
                               __('Slider Style 5', 'brando-addons') => 'brando-owl-slider5', 
                               __('Background Slider 1', 'brando-addons') => 'brando-owl-slider6',
                               __('Background Slider 2', 'brando-addons') => 'brando-owl-slider7',
                              ),
              'description' => __('Choose a pre-made Image Slider Style', 'brando-addons'),
          ),
          array(
              'type' => 'brando_preview_image',
              'heading' => __('Select pre-made style', 'brando-addons'),
              'param_name' => 'slider_preview_image',
              'admin_label' => true,
              'value' => array(__('Slider image', 'brando-addons') => '',
                               __('Slider Style 1', 'brando-addons') => 'brando-owl-slider1',
                               __('Slider Style 2', 'brando-addons') => 'brando-owl-slider2', 
                               __('Slider Style 3', 'brando-addons') => 'brando-owl-slider3',
                               __('Slider Style 4', 'brando-addons') => 'brando-owl-slider4',
                               __('Slider Style 5', 'brando-addons') => 'brando-owl-slider5', 
                               __('Background Slider 1', 'brando-addons') => 'brando-owl-slider6',
                               __('Background Slider 2', 'brando-addons') => 'brando-owl-slider7',
                              ),
          ),
          array(
                'type' => 'brando_custom_switch_option',
                'holder' => 'div',
                'class' => '',
                'heading' => __('Show Pagination', 'brando-addons'),
                'param_name' => 'show_pagination',
                'value' => array(__('OFF', 'brando-addons') => '0', 
                                 __('ON', 'brando-addons') => '1'
                                ),
                'description' => __( 'Select ON to show pagination in slider', 'brando-addons' ),
                'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
          ),
          array(
              'type' => 'dropdown',
              'heading' => __('Pagination Style', 'brando-addons'),
              'param_name' => 'show_pagination_style',
              'admin_label' => true,
              'value' => array(__('Select Pagination Style', 'brando-addons') => '',
                               __('Dot Style', 'brando-addons') => '0',
                               __('Line Style', 'brando-addons') => '1',
                               __('Round Style', 'brando-addons') => '2',
                              ),
              'dependency' => array( 'element' => 'show_pagination', 'value' => array('1') ),
          ),
          array(
              'type' => 'dropdown',
              'heading' => __('Pagination Color Style', 'brando-addons'),
              'param_name' => 'show_pagination_color_style',
              'admin_label' => true,
              'value' => array(__('Select Pagination Color Style', 'brando-addons') => '',
                               __('Dark Style', 'brando-addons') => '0',
                               __('Light Style', 'brando-addons') => '1'
                              ),
              'dependency' => array( 'element' => 'show_pagination', 'value' => array('1') ),
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Show Navigation', 'brando-addons'),
              'param_name' => 'show_navigation',
              'value' => array(__('OFF', 'brando-addons') => '0', 
                               __('ON', 'brando-addons') => '1'
                              ),
              'description' => __( 'Select ON to show navigation in slider', 'brando-addons' ),
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
          ),
          array(
              'type' => 'dropdown',
              'heading' => __('Navigation Style', 'brando-addons'),
              'param_name' => 'show_navigation_style',
              'admin_label' => true,
              'value' => array(__('Select Navigation Style', 'brando-addons') => '',
                               __('Next/Prev Black Arrow', 'brando-addons') => '0',
                               __('Next/Prev White Arrow', 'brando-addons') => '1'
                              ),
              'dependency' => array( 'element' => 'show_navigation', 'value' => array('1') ),
          ),
          array(
              'type' => 'dropdown',
              'heading' => __('Cursor Color Style', 'brando-addons'),
              'param_name' => 'show_cursor_color_style',
              'admin_label' => true,
              'value' => array(__('Select Cursor Color Style', 'brando-addons') => '',
                               __('White Cursor', 'brando-addons') => 'white-cursor',
                               __('Black Cursor', 'brando-addons') => 'black-cursor',
                               __('Default Cursor', 'brando-addons') => 'no-cursor',
                              ),
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider7') ),
          ),
          array(
              'type' => 'attach_image',
              'heading' => __('Slide Image', 'brando-addons'),
              'param_name' => 'brando_image',
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider6') ),
              'holder' => 'div',
              'group' => 'Background Slider Data',
          ),
          array(
              'type' => 'textfield',
              'heading' => __('Title', 'brando-addons'),
              'param_name' => 'background_slide_title',
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider6','brando-owl-slider7') ),
              'group' => 'Background Slider Data',
          ),
          array(
              'type' => 'textarea',
              'heading' => __('Subtitle', 'brando-addons'),
              'param_name' => 'background_slide_subtitle',
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider6','brando-owl-slider7') ),
              'group' => 'Background Slider Data',
          ),
          array(
              'type' => 'textfield',
              'heading' => __('Designation', 'brando-addons'),
              'param_name' => 'brando_designation',
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider7') ),
              'group' => 'Background Slider Data',
          ),
          array(
            'type' => 'colorpicker',
            'class' => '',
            'heading' => __( 'Title Color', 'brando-addons' ),
            'param_name' => 'brando_title_color',
            'description' => __( 'Choose Title Color', 'brando-addons' ),
            'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider6','brando-owl-slider7') ),
            'group' => 'Color',
          ),
          array(
            'type' => 'colorpicker',
            'class' => '',
            'heading' => __( 'Subtitle Color', 'brando-addons' ),
            'param_name' => 'brando_subtitle_color',
            'description' => __( 'Choose Subtitle Color', 'brando-addons' ),
            'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider6','brando-owl-slider7') ),
            'group' => 'Color',
          ),
          array(
              'type' => 'dropdown',
              'heading' => __('Transition Style', 'brando-addons'),
              'param_name' => 'transition_style',
              'admin_label' => true,
              'value' => array(__('Select Transition Style', 'brando-addons') => '',
                               __('Slide Style', 'brando-addons') => 'slide',
                               __('Fade Style', 'brando-addons') => 'fade',
                               __('BackSlide Style', 'brando-addons') => 'backSlide',
                               __('GoDown Style', 'brando-addons') => 'goDown',
                               __('FadeUp Style', 'brando-addons') => 'fadeUp'
                               
                              ),
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
              'group' => 'Slider Configuration',
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Autoplay', 'brando-addons'),
              'param_name' => 'autoplay',
              'value' => array(__('False', 'brando-addons') => '0', 
                               __('True', 'brando-addons') => '1'
                              ),
              'description' => __( 'Select TRUE to autoplay slider', 'brando-addons' ),
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
              'group' => 'Slider Configuration',
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Stop On Hover', 'brando-addons'),
              'param_name' => 'stoponhover',
              'value' => array(__('False', 'brando-addons') => '0', 
                               __('True', 'brando-addons') => '1'
                              ),
              'description' => __( 'Select TRUE to stop autoplay when hover on slider', 'brando-addons' ),
              'dependency'  => array( 'element' => 'autoplay', 'value' => array('1') ),
                'group' => 'Slider Configuration',
          ),
          
          array(
              'type' => 'dropdown',
              'heading' => __('Slide Delay Time', 'brando-addons'),
              'param_name' => 'slidespeed',
              'admin_label' => true,
              'value' => array(__('Select Slide Delay Time', 'brando-addons') => '',
                               __('500', 'brando-addons') => '500',
                               __('600', 'brando-addons') => '600',
                               __('700', 'brando-addons') => '700',
                               __('800', 'brando-addons') => '800',
                               __('900', 'brando-addons') => '900',
                               __('1000', 'brando-addons') => '1000',
                               __('2000', 'brando-addons') => '2000',
                               __('3000', 'brando-addons') => '3000',
                               __('4000', 'brando-addons') => '4000',
                               __('5000', 'brando-addons') => '5000',
                               __('6000', 'brando-addons') => '6000',
                               __('7000', 'brando-addons') => '7000',
                               __('8000', 'brando-addons') => '8000',
                               __('9000', 'brando-addons') => '9000',
                               __('10000', 'brando-addons') => '10000',
                              ),
              'description' => __('Select slide delay time (1ms = 100)', 'brando-addons'),
              'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
              'group' => 'Slider Configuration',
          ),
          array(
             'type'        => 'textfield',
             'heading'     => __('Title Font Size', 'brando-addons' ),
             'param_name' => 'title_font_size',
             'description' => __( 'Define font size like 12px', 'brando-addons' ),
             'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider5') ),
             'group' => 'Slider Configuration',
          ),
          array(
             'type'        => 'textfield',
             'heading'     => __('Title Line Height', 'brando-addons' ),
             'param_name' => 'title_line_height',
             'description' => __( 'Define line height like 12px', 'brando-addons' ),
             'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider5') ),
             'group' => 'Slider Configuration',
          ),
          array(
             'type'        => 'textfield',
             'heading'     => __('Slider ID', 'brando-addons' ),
             'description' => 'Optional - Define element id (The id attribute specifies a unique id for an HTML element)',
             'param_name'  => 'brando_slider_id',
             'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
             'group'       => 'Slider ID & Class'
          ),
          array(
             'type'        => 'textfield',
             'heading'     => __('Slider Extra Class', 'brando-addons' ),
             'description' => 'Optional - add additional CSS class to this element, you can define multiple CSS class with use of space like "Class1 Class2"',
             'param_name'  => 'brando_slider_class',
             'dependency' => array( 'element' => 'slider_premade_style', 'value' => array('brando-owl-slider1','brando-owl-slider2','brando-owl-slider3','brando-owl-slider4','brando-owl-slider5','brando-owl-slider6','brando-owl-slider7') ),
             'group'       => 'Slider ID & Class'
          ),
      ),
  )
);
vc_map( 
  array(
      'name' => __('Add Slide', 'brando-addons'),
      'base' => 'brando_slide_content',
      'description' => __( 'A slide for the image slider', 'brando-addons' ),
      'as_child' => array('only' => 'brando_slider'), // Use only|except attributes to limit parent (separate multiple values with comma)
      'icon' => 'fa fa-picture-o brando-shortcode-icon', //URL or CSS class with icon image.
      'params' => array(
          array(
            'type' => 'dropdown',
            'heading' => __( 'Slider type', 'brando-addons' ),
            'param_name' => 'brando_slider_type',
            'value' => array(__( 'Image', 'brando-addons' ) => 'image',
                             __( 'Video', 'brando-addons' ) => 'video',
                            ),
            'std' => 'image',
          ),
          array(
              'type' => 'attach_image',
              'heading' => __('Slide Image', 'brando-addons'),
              'param_name' => 'image',
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('image') ),
              'holder' => 'div'
          ),
          array(
              'type' => 'attach_image',
              'heading' => __('Poster Image', 'brando-addons'),
              'param_name' => 'poster_image',
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('video') ),
              'holder' => 'div'
          ),
          array(
              'type' => 'attach_image',
              'heading' => __('Second Image', 'brando-addons'),
              'param_name' => 'right_image',
              'description' => __( 'Select image for Slider Style 2,Slider Style 4 and Background Slider 1 only.', 'brando-addons' ),
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('image','video') ),
              'holder' => 'div'
          ),
          array(
              'type' => 'attach_image',
              'heading' => __('Third Image', 'brando-addons'),
              'param_name' => 'brando_third_image',
              'description' => __( 'Select image for Slider Style 4 only.', 'brando-addons' ),
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('image','video') ),
              'holder' => 'div'
          ),
          array(
              'type' => 'textfield',
              'heading' => __('Title', 'brando-addons'),
              'param_name' => 'title',
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('image','video') ),
          ),
          array(
              'type' => 'textarea_html',
              'heading' => __('Content', 'brando-addons'),
              'param_name' => 'content',
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('image','video') ),
          ),
          array(
            'type'        => 'vc_link',
            'heading'     => __('Button Configuration', 'brando-addons' ),
            'param_name'  => 'button_config',
            'admin_label' => true,
            'description' => __( 'Select image for Slider Style 2 only.', 'brando-addons' ),
            'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('image','video') ),
          ),
          array(
            'type' => 'dropdown',
            'heading' => __( 'Video Type', 'brando-addons' ),
            'param_name' => 'video_type',
            'value' => array(__('Select Video Type', 'brando-addons') => '',
                             __( 'Self', 'brando-addons' ) => 'self',
                             __( 'External', 'brando-addons' ) => 'external',
                            ),
            'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('video') ),
            'group' => 'Video Block',
          ),
          array(
            'type' => 'textfield',
            'heading' => __('MP4 Video URL', 'brando-addons'),
            'param_name' => 'single_image_mp4_video',
            'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
            'group' => 'Video Block',
          ), 
          array(
            'type' => 'textfield',
            'heading' => __('OGG Video URL', 'brando-addons'),
            'param_name' => 'single_image_ogg_video',
            'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
            'group' => 'Video Block',
          ), 
          array(
            'type' => 'textfield',
            'heading' => __('WEBM Video URL', 'brando-addons'),
            'param_name' => 'single_image_webm_video',
            'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
            'group' => 'Video Block',
          ), 
          array(
            'type' => 'textfield',
            'heading' => __('Youtube / Vimeo Video Embed URL', 'brando-addons'),
            'description' => __( 'Add YOUTUBE VIDEO EMBED URL like https://www.youtube.com/embed/xxxxxxxxxx, you will get this from youtube embed iframe src code. or add VIMEO VIDEO EMBED URL like https://player.vimeo.com/video/xxxxxxxx, you will get this from vimeo embed iframe src code. Please <a href="http://wpdemos.themezaa.com/brando/documentation/how-to-manage-youtube-and-vimeo-video-parameters/" target="_blank">click here</a> to manage video parameters like autoplay and loop video.', 'brando-addons' ),            
            'param_name' => 'external_video_url',
            'dependency'  => array( 'element' => 'video_type', 'value' => array('external') ),
            'group' => 'Video Block',
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Add Fullscreen Class', 'brando-addons'),
              'param_name' => 'video_fullscreen',
              'value' => array(__('No', 'brando-addons') => '0', 
                               __('Yes', 'brando-addons') => '1'
                              ),
              'std' => '1',
              'dependency'  => array( 'element' => 'brando_slider_type', 'value' => array('video') ),
              'group' => 'Video Block',
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Autoplay', 'brando-addons'),
              'param_name' => 'video_autoplay',
              'value' => array(__('No', 'brando-addons') => '0', 
                               __('Yes', 'brando-addons') => '1'
                              ),
              'std' => '1',
              'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
              'group' => 'Video Block',
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Mute', 'brando-addons'),
              'param_name' => 'video_muted',
              'value' => array(__('No', 'brando-addons') => '0', 
                               __('Yes', 'brando-addons') => '1'
                              ),
              'std' => '1',
              'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
              'group' => 'Video Block',
          ),
          array(
              'type' => 'brando_custom_switch_option',
              'holder' => 'div',
              'class' => '',
              'heading' => __('Loop', 'brando-addons'),
              'param_name' => 'video_loop',
              'value' => array(__('No', 'brando-addons') => '0', 
                               __('Yes', 'brando-addons') => '1'
                              ),
              'std' => '1',
              'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
              'group' => 'Video Block',
          ),
          array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Enable Opacity', 'brando-addons'),
            'param_name' => 'enable_opacity',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),
            'std' => '1',
            'description' => __( 'Select TRUE to enable opacity.', 'brando-addons' ),
            'group' => 'Style',
          ),
          array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Enable Separator', 'brando-addons'),
            'param_name' => 'enable_separator',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),
            'description' => __( 'Select TRUE to enable separator.', 'brando-addons' ),
            'group' => 'Style',
          ),
          array(
            'type' => 'colorpicker',
            'class' => '',
            'heading' => __( 'Title Color', 'brando-addons' ),
            'param_name' => 'title_color',
            'description' => __( 'Choose Title Color', 'brando-addons' ),
            'group' => 'Style',
          ),
          array(
            'type' => 'colorpicker',
            'class' => '',
            'heading' => __( 'Separator Color', 'brando-addons' ),
            'param_name' => 'sep_color',
            'description' => __( 'Choose Separator Color', 'brando-addons' ),
            'dependency' => array( 'element' => 'enable_separator', 'value' => array('1') ),
            'group' => 'Style',
          ),
          array(
            'type' => 'textfield',
            'heading' => __('Separator Height', 'brando-addons'),
            'param_name' => 'separator_height',
            'dependency' => array( 'element' => 'enable_separator', 'value' => array('1') ),
            'group' => 'Style',
          ),

        ),
    ) 
);
/* Main Slider class*/
if(class_exists('WPBakeryShortCodesContainer')){ 
  class WPBakeryShortCode_brando_slider extends WPBakeryShortCodesContainer { }
}
if(class_exists('WPBakeryShortCode')){
  class WPBakeryShortCode_brando_slide_content extends WPBakeryShortCode { }
}
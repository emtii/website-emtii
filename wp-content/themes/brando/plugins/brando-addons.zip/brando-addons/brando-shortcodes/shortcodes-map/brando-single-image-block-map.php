<?php
/**
 * Map For Single Image Block
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Single Image Block */
/*-----------------------------------------------------------------------------------*/

vc_map( array(
      'name' => __( 'Single Image/Video Block', 'brando-addons' ),
      'base' => 'brando_image_block',
      'category' => 'Brando',
      'icon' => 'fa fa-file-video-o brando-shortcode-icon',
      'description' => __( 'Create a image block', 'brando-addons' ),
      'params' => array(
        array(
          'type' => 'dropdown',
          'holder' => 'div',
          'class' => '',
          'heading' => __( 'Image Block Style', 'brando-addons' ),
          'param_name' => 'brando_image_block_premade_style',
          'value' => array(__('Select Image Block Style', 'brando-addons') => '',
                           __('Image Block Style1', 'brando-addons') => 'image-block-1',
                           __('Image Block Style2', 'brando-addons') => 'image-block-2',
                           __('Image Block Style3', 'brando-addons') => 'image-block-3',
                           __('Image Block Style4', 'brando-addons') => 'image-block-4',
                           __('Image Block Style5', 'brando-addons') => 'image-block-5',
                           __('Image Block Style6', 'brando-addons') => 'image-block-6',
                          ),
        ),
        array(
          'type' => 'brando_preview_image',
          'heading' => __('Select pre-made style for image block', 'brando-addons'),
          'param_name' => 'brando_image_block_preview_image',
          'admin_label' => true,
          'value' => array(__('Select Image Block Style', 'brando-addons') => '',
                           __('Image Block Style1', 'brando-addons') => 'image-block-1',
                           __('Image Block Style2', 'brando-addons') => 'image-block-2',
                           __('Image Block Style3', 'brando-addons') => 'image-block-3',
                           __('Image Block Style4', 'brando-addons') => 'image-block-4',
                           __('Image Block Style5', 'brando-addons') => 'image-block-5',
                           __('Image Block Style6', 'brando-addons') => 'image-block-6',
                          ),
        ),
        array(
            'type' => 'attach_image',
            'heading' => __( 'Background Image', 'brando-addons' ),
            'param_name' => 'brando_image',
            'dependency' => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-1','image-block-6') ),
        ),
        array(
          'type' => 'textfield',
          'heading' => __('Title', 'brando-addons'),
          'param_name' => 'brando_title',
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-2','image-block-3','image-block-4','image-block-5') ),
        ),
        array(
          'type' => 'textarea_html',
          'heading' => __('Content', 'brando-addons'),
          'param_name' => 'content',
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-2','image-block-3','image-block-4','image-block-6') ),
        ),
        array(
          'type' => 'colorpicker',
          'heading' => __('Title Color', 'brando-addons'),
          'param_name' => 'brando_title_color',
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-2','image-block-3','image-block-4','image-block-5') ),
          'group' => 'Settings',
        ),
        array(
          'type' => 'colorpicker',
          'heading' => __('Background Color', 'brando-addons'),
          'param_name' => 'brando_background_color',
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-5') ),
          'group' => 'Settings',
        ),
        array(
          'type' => 'textfield',
          'heading' => __('Date', 'brando-addons'),
          'param_name' => 'brando_date',
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-3') ),
        ),
        array(
            'type'        => 'vc_link',
            'heading'     => __('Button Configuration', 'brando-addons' ),
            'param_name'  => 'button_config',
            'admin_label' => true,
            'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-3') ),
        ),
        array(
          'type' => 'brando_custom_switch_option',
          'heading' => __('Show Separator', 'brando-addons'),
          'param_name' => 'brando_show_separator',
          'value' => array(__('No', 'brando-addons') => '0', 
                           __('Yes', 'brando-addons') => '1'
                          ),
          'description' => __( 'Select YES to show Separator', 'brando-addons' ),
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-2','image-block-4') ),
          'group' => 'Settings',
        ),
        array(
          'type' => 'colorpicker',
          'class' => '',
          'heading' => __( 'Separator Color', 'brando-addons' ),
          'param_name' => 'brando_sep_color',
          'dependency' => array( 'element' => 'brando_show_separator', 'value' => array('1') ),
          'group' => 'Settings',
        ),  
        array(
          'type' => 'textfield',
          'heading' => __('Separator Height', 'brando-addons' ),
          'param_name' => 'separator_height',
          'dependency' => array( 'element' => 'brando_show_separator', 'value' => array('1') ),
          'description' => __( 'Define custom separator height in px like 2px', 'brando-addons' ),
          'group' => 'Settings',
        ),
        array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Scroll To Section', 'brando-addons'),
            'param_name' => 'brando_scroll_to_section',
            'value' => array(__('NO', 'brando-addons') => '0', 
                             __('YES', 'brando-addons') => '1'
                            ),
            'description' => __( 'Select Yes to show scroll to section icon', 'brando-addons' ),
            'dependency' => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-1') ),
      ),
      array(
          'type' => 'textfield',
          'heading' => __('Scroll to section Id', 'brando-addons'),
          'description' => __( 'Define section id like #about', 'brando-addons' ),
          'param_name' => 'brando_section_id',
          'dependency' => array( 'element' => 'brando_scroll_to_section', 'value' => array('1') ),
        ),
        array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Position Relative', 'brando-addons'),
            'param_name' => 'position_relative',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),  
            'dependency' => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-1','image-block-2') ),
        ),
        array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Add Container Class', 'brando-addons'),
            'param_name' => 'brando_container',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),
            'dependency' => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-1','image-block-2') ),
        ),
        array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Add Fullscreen Class', 'brando-addons'),
            'param_name' => 'brando_fullscreen',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),
            'dependency' => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-1','image-block-2') ),
        ),
        array(
          'type' => 'dropdown',
          'heading' => __( 'Video Type', 'brando-addons' ),
          'param_name' => 'video_type',
          'value' => array(__('Select Video Type', 'brando-addons') => '',
                           __( 'Self', 'brando-addons' ) => 'self',
                           __( 'External', 'brando-addons' ) => 'external',
                          ),
          'dependency'  => array( 'element' => 'brando_image_block_premade_style', 'value' => array('image-block-1','image-block-2','image-block-3','image-block-4','image-block-5','image-block-6')),
        ),
        array(
          'type' => 'textfield',
          'heading' => __('MP4 Video URL', 'brando-addons'),
          'param_name' => 'single_image_mp4_video',
          'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
        ), 
        array(
          'type' => 'textfield',
          'heading' => __('OGG Video URL', 'brando-addons'),
          'param_name' => 'single_image_ogg_video',
          'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
        ), 
        array(
          'type' => 'textfield',
          'heading' => __('WEBM Video URL', 'brando-addons'),
          'param_name' => 'single_image_webm_video',
          'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
        ), 
        array(
          'type' => 'textfield',
          'heading' => __('Youtube / Vimeo Video Embed URL', 'brando-addons'),
          'description' => __( 'Add YOUTUBE VIDEO EMBED URL like https://www.youtube.com/embed/xxxxxxxxxx, you will get this from youtube embed iframe src code. or add VIMEO VIDEO EMBED URL like https://player.vimeo.com/video/xxxxxxxx, you will get this from vimeo embed iframe src code', 'brando-addons' ),            
          'param_name' => 'external_video_url',
          'dependency'  => array( 'element' => 'video_type', 'value' => array('external') ),
        ),
        array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Add Fullscreen Class', 'brando-addons'),
            'param_name' => 'video_fullscreen',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),
            'dependency'  => array( 'element' => 'video_type', 'value' => array('external') ),
        ),
        array(
            'type' => 'brando_custom_switch_option',
            'holder' => 'div',
            'class' => '',
            'heading' => __('Enable Mute', 'brando-addons'),
            'param_name' => 'enable_mute',
            'value' => array(__('No', 'brando-addons') => '0', 
                             __('Yes', 'brando-addons') => '1'
                            ),  
            'dependency'  => array( 'element' => 'video_type', 'value' => array('self') ),
        ),
        array(
          'type'        => 'textfield',
          'heading'     => __('Width', 'brando-addons' ),
          'description' => __( 'Define IFRAME width like 500', 'brando-addons' ),                        
          'param_name'  => 'width',
          'dependency'  => array( 'element' => 'video_type', 'value' => array('self','external') ),
          'group'       => 'Width & Height'
        ),
        array(
          'type'        => 'textfield',
          'heading'     => __('Height', 'brando-addons' ),
          'param_name'  => 'height',
          'description' => __( 'Define IFRAME height like 400', 'brando-addons' ),                              
          'dependency'  => array( 'element' => 'video_type', 'value' => array('self','external') ),
          'group'       => 'Width & Height'
        ),
      $brando_vc_extra_id,
      $brando_vc_extra_class, 
)));